<?php
class Matakuliah_model extends CI_Model {
    public $matakuliah;
    public $waktu;
    public $dosen;
    public $tempat;
}

?>